#ifndef RESULTADOS_H
#define RESULTADOS_H

void mostrarResultados();
void mostrarTablaDePosiciones();

#endif /* RESULTADOS_H */